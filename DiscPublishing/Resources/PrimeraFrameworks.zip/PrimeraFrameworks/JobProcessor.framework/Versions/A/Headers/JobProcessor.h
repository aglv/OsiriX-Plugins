#pragma once
#import <PTRobot/PTRobot.h>
#include "carbon/carbon.h"

#ifdef __cplusplus
extern "C" {
#endif

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the JOBPROCESSOR_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// JOBPROCESSOR_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef JOBPROCESSOR_EXPORTS
#define JOBPROCESSOR_API __declspec(dllexport)
#else
#define JOBPROCESSOR_API __declspec(dllimport)
#endif


////////////////////////////////////////////////////////
//                                                    //				
//			      Job Processor Defines               //
//                                                    //
////////////////////////////////////////////////////////
#define MAX_DISC_ERRORS 10	//Added Version 1.09
#define MAX_ROBO_DRIVES 4

#define BYTES_PER_SECTOR_DATA	2048
#define BYTES_PER_SECTOR_AUDIO	2352
#define BYTES_PER_SECTOR_MODE2	2336

#define INDEX_SPEED_0	1000				// This signals JP to use an "index" based speed
											// rather an actual burn speed (indexes start at 1000)
											// This is for Fastest, Fast, Medium, Slow, Slowest logic
											// where the Fastest = 1000, Fast = 1001, etc.
											// and the actual burn speed is determined at run-time based on disc


#define  CDROM          0x00000201
#define  CDR            0x00000202
#define  CDRW           0x00000203
#define  DVDROM         0x00000205
#define  DVDR           0x00000204
#define  DVDRW          0x00000207
#define  DVDPRW         0x00000209
#define  DVDRAM         0x00000206
#define  ROBOTICS       0x00000208
#define  OTHER          0x00000220

// MediaTypes
#define MEDIA_CD		0
#define MEDIA_DVD		1
#define MEDIA_DONTCARE  2

// Source Bins
#define BIN_DONT_CARE	0
#define LEFT_BIN_LOC		1
#define RIGHT_BIN_LOC		2

///////////////////////////
//
//	Robot Options
//
///////////////////////////
#define PTOPT_KIOSKMODE 		0x00000001


// Primary Volume Descriptor types
#define PVD_NONE			0
#define PVD_SYSTEMID		1
#define PVD_VOLUMEID		2
#define PVD_PUBLISHERID		3
#define PVD_DATAPREPID		4
#define PVD_APPLICATIONID	5


// Job Action definitions, used in the JP_JobActionCommand function
#define JOB_ACTION_PAUSE				0
#define JOB_ACTION_RESUME				1
#define JOB_ACTION_ABORT				2
#define JOB_ACTION_START_PROCESSING		3
#define JOB_ACTION_UNLOAD_DISC			4
#define JOB_ACTION_REJECT_DISC			5

//System Mode, 
#define NORMAL 0
#define KIOSK 1


// Job State
#define JOB_NOT_STARTED 0
#define JOB_RECORDING   1		// TODO: SEVERAL OF THESE NOT USED - WHY?
#define JOB_PRINTING    2
#define JOB_COMPLETED   3
#define JOB_ABORTED     4
#define JOB_PAUSED		5 
#define JOB_RESUMED		6
#define JOB_FAILED      7
#define JOB_VERIFYING	8
#define JOB_READING		9
#define	JOB_ABORTING	10


//Disc State
#define DISC_WAIT_FOR_REC	0
#define DISC_LOADING		1
#define DISC_RECORDING		2
#define DISC_VERIFYING		3
#define DISC_WAIT_FOR_PTR	4
#define DISC_PRINTING		5
#define DISC_UNLOADING		6
#define DISC_FINISHED		7
#define DISC_READING		8
#define DISC_REJECTING		9
#define DISC_TESTING        10

//Disc load states
#define DISCLOAD_LOADING		0
#define DISCLOAD_LOADED			1
#define DISCLOAD_PROCESSING		2
#define DISCLOAD_PROCESSED		3
#define DISCLOAD_UNLOADING_UNLOADED	4

// Job Type
#define JP_JOB_AUDIO		0
#define JP_JOB_DATA			1
#define JP_JOB_IMAGE		2
#define JP_JOB_PRINT_ONLY	3
#define JP_JOB_MULTISESSION 4
#define JP_JOB_READ			5		// Save discs to GIs, Audio files, or data files (using robotics)
#define JP_JOB_COPY			6		// Copy discs
#define JP_JOB_SAVE_GI		7		// Save a disc as a GI - not using robotics
#define JP_JOB_DVDVIDEO     8
#define JP_JOB_BDMV			9
#define JP_JOB_BDAV			11
#define JP_JOB_UNKNOWN 		10


// Image Type
#define GLOBAL_IMAGE	0
#define OTHER_IMAGE		1

// Read Data Type
#define READ_DATA	0
#define READ_GI		1



///////////////////////////////////////////////////////////////
// RECORDING ENGINE RELATED FLAGS
///////////////////////////////////////////////////////////////

//**************************
// ** Disc CREATION flags ** 
//**************************
// Correspond directly to PrimoSDK.h flags
#define  CREATEOPT_DVDPRQUICK              0x00000800
#define  CREATEOPT_ORIGDATE                0x00001000
#define  CREATEOPT_USERTIMESET             0x00001000 // use for streamed files since they don't have an "original date"
#define  CREATEOPT_SETNOW                  0x00002000
#define  CREATEOPT_MODE1                   0x00004000
#define  CREATEOPT_MODE2                   0x00008000
#define  CREATEOPT_CLOSEDISC               0x00010000
#define  CREATEOPT_COPYPREGAP              0x00020000
#define  CREATEOPT_NOPREGAP                0x00040000
#define  CREATEOPT_RESETDRIVES             0x00080000
#define  CREATEOPT_SAO                     0x00800000
#define  CREATEOPT_TAO                     0x01000000
#define  CREATEOPT_VIDEOCD                 0x02000000
#define  CREATEOPT_CHECKDUPLI              0x04000000
#define  CREATEOPT_DVDIMAGE                0x08000000
#define  CREATEOPT_FAST_WRITE              0x80000000
#define  CREATEOPT_CLOSEBORDER             0x00100000

#define FileSys_ISO_Level_2_Long    0  // IN/OUT: ISO 9660 Level 2 with long names
#define FileSys_Joliet            1  // IN/OUT: Joliet
#define FileSys_UDF102            2 // IN/OUT: UDF 1.02
#define FileSys_UDF25             3 // IN/OUT: UDF 2.5
#define FileSys_UDF26             4 // IN/OUT: UDF 2.6	
#define FileSys_ISO_Level_1         5  // IN/OUT: ISO 9660 Level 1	
#define FileSys_ISO_Level_2         6  // IN/OUT: ISO 9660 Level 2	
#define FileSys_UDF15             7 // IN/OUT: UDF 1.5
#define FileSys_UDF2              8 // IN/OUT: UDF 2.0
#define FileSys_UDF201            9 // IN/OUT: UDF 2.01
#define FileSys_NONE			  99	
	
/*#define NONE				0
#define ISO_Level_1       (1 << 1)  // IN/OUT: ISO 9660 Level 1	
#define ISO_Level_2       (1 << 2)  // IN/OUT: ISO 9660 Level 2	
#define ISO_Level_2_Long  (1 << 3)  // IN/OUT: ISO 9660 Level 2 with long names
#define ISO_Versionless   (1 << 4)  // IN/OUT: ISO 9660 No Version
#define Joliet            (1 << 5)  // IN/OUT: Joliet
#define UDF102            (1 << 10) // IN/OUT: UDF 1.02
#define UDF15             (1 << 11) // IN/OUT: UDF 1.5
#define UDF2              (1 << 12) // IN/OUT: UDF 2.0
#define UDF25             (1 << 13) // IN/OUT: UDF 2.5
#define UDF26             (1 << 14) // IN/OUT: UDF 2.6
#define UDF201            (1 << 15) // IN/OUT: UDF 2.01	*/

//***********************
// ** Disc WRITE flags **
//***********************
// Correspond directly to PrimoSDK.h flags
#define  WRITEOPT_OPENTRAYEJECT				0x00000001
#define  WRITEOPT_CLOSETRAY					0x00000002
#define  WRITEOPT_LOCK						0x00000004
#define  WRITEOPT_UNLOCK					0x00000008
#define  WRITEOPT_TEST						0x00000010
#define  WRITEOPT_WRITE						0x00000020
#define  WRITEOPT_IMMEDIATE					0x00000040
#define  WRITEOPT_BURNPROOF					0x00000080
#define  WRITEOPT_HIGHDENSITY				0x80000000    // used to be 0x100 but that conflicts with ISOLEVEL1 below.
#define  WRITEOPT_COPYRIGHT					0x00000200
#define  WRITEOPT_EMPHASIS					0x00000400
#define  WRITEOPT_ALLOW_NONSTANDARD_LAYER	0x00008000 // PrimoSDK_WriteImage flag to allow non-compliant layer break on DVD Video
#define  WRITEOPT_FORCE_REFRESH				0x00010000
#define  WRITEOPT_IMAGE_M1_2048				0x00020000
#define  WRITEOPT_IMAGE_M2_2336				0x00040000
#define  WRITEOPT_IMAGE_M2_2352				0x00080000


//****************
// ** JOB flags **
//****************
// NOT in PrimoSDK.h - these are our flags
#define  JOBOPT_VERIFY						0x00000001
#define  JOBOPT_REJECT_IF_NOT_BLANK			0x00000002
#define  JOBOPT_PRINT_REJECT				0x00000004
#define	 JOBOPT_NEWVOLUME					0x00000008

///////////////////////////////////////////////////////////////
// END OF RECORDING ENGINE RELATED FLAGS
///////////////////////////////////////////////////////////////


// Tray Options
#define TRAY_OPEN			0x01
#define TRAY_CLOSE			0x02
#define TRAY_IMMEDIATE		0x04

// Drive Capabilites
#define DRVCAP_BURNPROOF			0x00000001
#define DRVCAP_CDTEXT				0x00000002
#define DRVCAP_AWS					0x00000004
#define DRVCAP_DVDROM				0x00000008
#define DRVCAP_OPEN_AFTER_TEST		0x00000010
#define DRVCAP_OPEN_AFTER_RECORD	0x00000020

// Possible recording states
#define REC_COMPLETE_SUCCESS		0
#define REC_COMPLETE_ERROR			1
#define REC_IN_PROCESS				2 
#define REC_NOT_STARTED				3
#define VER_IN_PROCESS				4
#define VER_COMPLETE_SUCCESS		5
#define VER_COMPLETE_ERROR			6
#define READ_IN_PROCESS				7
#define READ_COMPLETE_SUCCESS		8
#define READ_COMPLETE_ERROR			9
#define DRV_DISC_LOADED				10

#define REC_SPEED_MAX				0

///////////////////////////
//
//  Languages
//
///////////////////////////
#define ENGLISH			0
#define JAPANESE		1
#define	GERMAN			2
#define FRENCH			3
#define SPANISH			4
#define ITALIAN			5


#define MAX_STRING 512			// Max String length for error messages

////////////////////////////////////////////////////////
//                                                    //				
//			      Job Processor Types                 //
//                                                    //
////////////////////////////////////////////////////////
typedef UInt32 DriveID;

typedef struct tagDriveSpeedInfo
{
	UInt32	dwCDReadSpeeds[16];		// Array of CD Read speeds
	UInt32	dwCDWriteSpeeds[16];	// Array of CD Write speeds
	UInt32	dwCDRewriteSpeeds[16];	// Array of CD Rewrite speeds
	int		nNumCDReadSpeeds;		// Num CD read speeds, size of dwCDReadSpeeds
	int		nNumCDWriteSpeeds;		// Num CD write speeds, size of dwCDWriteSpeeds
	int		nNumCDRewriteSpeeds;	// Num CD rewrite speeds, size of dwCDRewriteSpeeds
	UInt32	dwDVDReadSpeeds[16];	// Array of DVD Read speeds
	UInt32	dwDVDWriteSpeeds[16];	// Array of DVD Read speeds
	UInt32	dwDVDRewriteSpeeds[16];	// Array of DVD Read speeds
	int		nNumDVDReadSpeeds;		// Num DVD read speeds, size of dwDVDReadSpeeds
	int		nNumDVDWriteSpeeds;		// Num DVD write speeds, size of dwDVDWriteSpeeds
	int		nNumDVDRewriteSpeeds;	// Num DVD rewrite speeds, size of dwDVDRewriteSpeeds
} DriveSpeed, *pDriveSpeed;

typedef struct tagDriveStatistics
{
	int nGoodDiscs;
	int nBadDiscs;
	int nErrRecording;
	int nErrRecordingMedia;
	int nErrVerifying;
	int nErrVerifyingMedia;
	int nErrReading;
	int nErrReadingMedia;
	int nErrDriveNotReady;
} DriveStatistics, *pDriveStatistics;

typedef struct tagRecordingStatus
{
	UInt32 dwDriveID;
	UInt32 dwJobID;
	UInt32 dwRecordStat;		// Recording Status
	bool  fError;			// Flag to tell if error occurred or not
	UInt32 dwErrorCommand;	// If error, command error occured
	UInt32 dwErrorSense;		// If error, Sense value of error
	UInt32 dwErrorASC;		// If error, ASC value of error
	UInt32 dwErrorASCQ;		// If error, ASCQ value of error
	UInt32 dwSectorsBurned;	// Number of sectors burned
	UInt32 dwSectorsTotal;	// Total num sectors for job
	int nDisc;				// 
	UInt32 dwPreviousSector;	// Sector on during last read/write (for calculating drive speed)
	UInt32 dwPreviousTime;	// Time during last read/write (for calculating drive speed)
	UInt32 dwSpeed;			// Current Read/Write speed - 1x units
	UInt32 dwLastSpeed;		// Last read/write speed (for averaging)
} RecordingStatus, *pRecordingStatus;


typedef struct tagDriveInfo
{
	char    szDriveDescr[128+1];     // Drive description
	char	tszOurDescr[128+1];       // Name re-assigned	 
	DriveID driveID;				// Drive ID	
	char	tszFirmwareVer[40];			// Drive FW version
	char	tszSerialNum[40];			// Drive Serial Number (or bridge board's)
	UInt32   dwRow;
	UInt32   dwCol;
	UInt32 dwBusType;
	bool fSupportsBR;
} DriveInfo, *pDriveInfo;

#define DISC_IN_DRIVE_YES 0
#define DISC_IN_DRIVE_NO 1
#define DISC_IN_DRIVE_MAYBE 2

/////////////////////////////////////////////////////////////
// Information retrieved for a disc within a specified drive
/////////////////////////////////////////////////////////////
typedef struct tagDiscInfo
{
	UInt32 dwMediumType;
	UInt32 dwMediumFormat;
	UInt32 dwErasable;
	UInt32 dwTracks;
	UInt32 dwUsed;
	UInt32 dwFree; 
	UInt32 dwProtectedDVD;
	UInt32 dwFlags;
	UInt32 dwMediumEx;
	UInt32 dwNumSpeeds;
	UInt32 dwDiscSpeedList[12];
	char tszMediaID[20];
	char tszMediaType[20];
	UInt32 dwFuture;
} DiscInfo, * pDiscInfo;

///////////////////////////////////////////////////////
// Information retrieved for a specified global Image
///////////////////////////////////////////////////////
typedef struct tagImageInfo
{									// See PrimoSDK.h for more info
	UInt32 dwMediumFormat;			// Disc format (see PrimoSDK_DiscInfo)
	UInt32 dwTracks;					// Number of tracks in the GI
	UInt32 dwUsed;					// Number of sectors used
	UInt32 dwMedium;					// media type GI was created from (see PrimoSDK_DiscInfo2)
	UInt32 dwMediumEx;				// physical type of the medium (see PrimoSDK_DiscInfo2)
} ImageInfo, * pImageInfo;



typedef struct tagPVDData
{
char tszSystemID[33];
char tszVolumeID[33];
char tszPublisherID[129];
char tszDataPreparerID[129];
char tszApplicationID[129];
} PVDData, *pPVDData;

typedef struct tagCreateDiscOptions
{
	DriveID DriveIDs[MAX_ROBO_DRIVES];	
	int nNumDrives;			
	UInt32 dwMultiSessionID; 
	int nSession;			
	char tszCheckFile[256];		
	bool fCheckPVD;
	bool fLoadUnloadOverride;
	PVDData PVD;
	bool fPreMasterData;
	UInt32 dwJobType;
} CreateDiscOptions, *pCreateDiscOptions;


typedef struct tagWriteDiscOptions
{
 	UInt32 dwFileSystem;
	UInt32 dwFileSystemBridge;
	UInt32 dwPrimoSDKCreateOpts;				// Disc Creation options - can be passed directly into PrimoSDK 
	UInt32 dwPrimoSDKWriteOpts;				// Disc Writing options  - can be passed directly into PrimoSDK 
	UInt32 dwJobOpts;						// Job options - related to but not directly in Recording engine
	UInt32 dwRecSpeed;
	int nNumCopies;
	int nSourceBin;	
	char tszPrintFile[256];
	char tszMergeFile[256];
	bool fPrintSettingsOverride;			// flag to say if the printer settings are being overridden or not
	PTPrinterSettings2 PrintSettings;		// printer settings to override
    SInt32 dwColorCartWarnPercent;
    SInt32 dwBlackCartWarnPercent;
    SInt32 dwCyanCartWarnPercent;
    SInt32 dwMagentaCartWarnPercent;
    SInt32 dwYellowCartWarnPercent;
} WriteDiscOptions, *pWriteDiscOptions;


typedef struct tagReadDiscOptions
{
	int nNumCopies;
	UInt32 dwReadSpeed;
	int nReadFormat;
	char tszReadLocation[256];
	bool fCreateSubfolders;
	int nSourceBin;
} ReadDiscOptions, *pReadDiscOptions;


typedef struct tagJPOptions
{
	char tszLogFile[256];			// full path of the log file
	char tszAppLogFile[256];
	int nLogLevel;				// Log Level to use
	int nNumRejectsInARow;		// The number of reject to allow in a row before an abort
	bool fCompleteAllCopies;	// flag to complete all copies regarless of errors.
	bool fQuietUIMode;			// flag to enable a "Quiet UI" mode
	bool fDisablePowerButton;	// Disable power button (customer request 1.14)
	bool fUseOldIniFile;		//use the old ini file (Version 2.5.1 for NKU)	
	bool fPrintFirst;
	bool fUseJPCallback;
	int nDriveSpinUpDelay;		//Added the following key per FogBugz 94
	int nDriveReadMediaDelay;   //Added the following key per FogBugz 94
} JPOptions, *pJPOptions;


/////////////////////
// SYSTEM ERRORS
/////////////////////
#define JPSYSERR_NONE				0
#define JPSYSERR_PTR_TRAY			1
#define JPSYSERR_CART_CODE			2
#define JPSYSERR_INPUT_EMPTY		3
#define JPSYSERR_PTR_COMM			4
#define JPSYSERR_CLR_EMPTY			5
#define JPSYSERR_BLK_EMPTY			6
#define JPSYSERR_BOTH_EMPTY			7
#define JPSYSERR_PICK				8
#define JPSYSERR_ARM_MOVE			9
#define JPSYSERR_CART_MOVE			10
#define JPSYSERR_ADMIN				11
#define JPSYSERR_INTERNAL_SW		12
#define JPSYSERR_NO_ROBODRIVES		13
#define JPSYSERR_OFFLINE			14
#define JPSYSERR_COVER_OPEN			15
#define JPSYSERR_PRINTER_PICK		16
#define JPSYSERR_MULTIPLE_PICK		17			// Ver 1.09 - BRAVO2 errors added 17-21
#define JPSYSERR_DROPPED_DISC_RECORDER 18 
#define JPSYSERR_DROPPED_DISC_PRINTER  19 
#define JPSYSERR_DROPPED_DISC_LEFTBIN  20 
#define JPSYSERR_DROPPED_DISC_REJECT 21 	
    
//Version 2.5 Added for BravoPRO
#define JPSYSERR_ALIGNNEEDED		22
#define JPSYSERR_COLOR_INVALID		23
#define JPSYSERR_BLACK_INVALID		24
#define JPSYSERR_BOTH_INVALID		25
#define JPSYSERR_NOCARTS			26
#define JPSYSERR_K_IN_CMY			27
#define JPSYSERR_CMY_IN_K			28
#define JPSYSERR_SWAPPED			29
#define JPSYSERR_PIGONPRO			30
#define JPSYSERR_ALIGNFAILED		31

//Version 3.0 new
#define JPSYSERR_DROPPED_DISC_PRINTER_FATAL		32
#define JPSYSERR_MULTIPLEDISCS_IN_RIGHTBIN		33
#define JPSYSERR_MULTIPLEDISCS_IN_LEFTBIN		34
#define JPSYSERR_CLR_EMPTY_FINAL				35
#define JPSYSERR_BLK_EMPTY_FINAL				36
#define JPSYSERR_BOTH_EMPTY_FINAL				37
#define JPSYSERR_WAITING_FOR_PRINTER			38
#define JPSYSERR_DROPPED_DISC_OTHER				39
#define JPSYSERR_NO_DISC_IN_PRINTER				40
#define JPSYSERR_DROPPED_DISC_RIGHTBIN			41
#define JPSYSERR_BUSY							42


/////////////////////////////////////////
// API RETURN VALUES
/////////////////////////////////////////
#define JOBERR_NONE					0
#define JOBERR_INTERNAL_RECORDING	1
#define JOBERR_INTERNAL_JOBPROC		2
#define JOBERR_INTERNAL_ROBOTICS	3
#define JOBERR_BURNFILE_INVALID		4
#define JOBERR_BURNFILE_TOO_MANY	5
#define JOBERR_BURNFILE_NONE		6
#define JOBERR_PRINTFILE_INVALID	7
#define JOBERR_JOBFILE_INVALID		8
#define JOBERR_STATUSFILE			9
#define JOBERR_MEDIA_INVALID		10
#define JOBERR_MEDIA_NO_SPACE		11
#define JOBERR_MEDIA_NOT_BLANK		12
#define JOBERR_DRIVE_OPENCLOSE		13
#define JOBERR_DRIVE_NOT_READY		14
#define JOBERR_DRIVE_NOT_ROBOTIC	15
#define JOBERR_ABORTED				16
#define JOBERR_DVD_INVALID			17
#define JOBERR_RECORDING			18
#define JOBERR_VERIFYING			19
#define JOBERR_REJECTS_TOO_MANY		20
#define JOBERR_SESSION_INVALID		21
#define JOBERR_CLIENT_INVALID		22
#define JOBERR_CLIENTMSG_INVALID	23
#define JOBERR_UNKNOWN_JOBTYPE		24
#define JOBERR_KEYVALUE_INVALID     25
#define JOBERR_TEMP_OVERFLOW		26
#define JOBERR_CDTEXT_INVALID		27
#define JOBERR_PRINTAPP_NOTINSTALLED  28
#define JOBERR_PRINTFILE_NOTEXIST   29
#define JOBERR_INVALIDCART_FOR_PRINT 30
#define JOBERR_READLOC_NO_SPACE		31
#define JOBERR_READING				32
#define JOBERR_INVALID_PVDFIELD		33
#define JOBERR_INVALID_PVDJOBTYPE	34
#define JOBERR_CREATING_IMAGE		35
#define JOBERR_NO_STATUS			36
#define JOBERR_NOT_SUPPORTED		37
#define JOBERR_INVALID_JOB_ID		38
#define JOBERR_STRING_TOO_LONG		39

#define	JOBERR_NOT_READY			98
#define THREAD_TERMINATED			99


// Using Robot Types from PTRobot


// ROBOTIC COMMANDS
// Bravo Commands
///////////////////////////////////
/*static const UInt8 CANCEL_LAST_COMMAND[8] =          {0x1b,0x04,0x09,0,0,0,0,0x28};
static const BYTE MOVE_LEFT_BIN_TO_RECORDER[8] = 		{0x1b,0x04,0x80,0,0,0,0,0x9f};
static const BYTE MOVE_LEFT_BIN_TO_PRINTER[8] = 		{0x1b,0x04,0x81,0,0,0,0,0xa0};
static const BYTE MOVE_LEFT_BIN_TO_RIGHT_BIN[8] = 	{0x1b,0x04,0x82,0,0,0,0,0xa1};
static const BYTE MOVE_RIGHT_BIN_TO_RECORDER[8] = 	{0x1b,0x04,0x83,0,0,0,0,0xa2};
static const BYTE MOVE_RIGHT_BIN_TO_PRINTER[8] = 		{0x1b,0x04,0x84,0,0,0,0,0xa3};
static const BYTE MOVE_RIGHT_BIN_TO_LEFT_BIN[8] =  	{0x1b,0x04,0x85,0,0,0,0,0xa4};
static const BYTE MOVE_RECORDER_TO_PRINTER[8] = 		{0x1b,0x04,0x86,0,0,0,0,0xa5};
static const BYTE MOVE_RECORDER_TO_RIGHT_BIN[8] = 	{0x1b,0x04,0x87,0,0,0,0,0xa6};
static const BYTE MOVE_RECORDER_TO_LEFT_BIN[8] = 		{0x1b,0x04,0x88,0,0,0,0,0xa7};
//static const BYTE MOVE_RECORDER_TO_REJECT[8] = 			{0x1b,0x04,0x89,0,0,0,0,0xa8};
static const BYTE MOVE_PRINTER_TO_RIGHT_BIN[8] = 		{0x1b,0x04,0x8a,0,0,0,0,0xa9};
static const BYTE MOVE_PRINTER_TO_LEFT_BIN[8] = 		{0x1b,0x04,0x8b,0,0,0,0,0xaa};
static const BYTE MOVE_PRINTER_TO_REJECT[8] = 			{0x1b,0x04,0x8c,0,0,0,0,0xab};

static const BYTE MOVE_TO_LEFT_BIN[8] = 						{0x1b,0x04,0x8d,0,0,0,0,0xac};
static const BYTE MOVE_TO_PRINTER[8] = 							{0x1b,0x04,0x8e,0,0,0,0,0xad};
static const BYTE MOVE_TO_RECORDER[8] = 						{0x1b,0x04,0x8f,0,0,0,0,0xae};
static const BYTE MOVE_TO_RIGHT_BIN[8] = 						{0x1b,0x04,0x90,0,0,0,0,0xaf};
static const BYTE MOVE_TO_REJECT[8] = 							{0x1b,0x04,0x91,0,0,0,0,0xb0};
static const BYTE PICK_DROP_DISC[8] = 							{0x1b,0x04,0x92,0,0,0,0,0xb1};
static const BYTE MOVE_PRINTER_TRAY_OUT[8] = 				{0x1b,0x04,0x93,0,0,0,0,0xb2};
static const BYTE MOVE_PRINTER_TRAY_IN[8] = 				{0x1b,0x04,0x94,0,0,0,0,0xb3};
static const BYTE CHANGE_CARTRIDGE[8] = 						{0x1b,0x04,0x95,0,0,0,0,0xb4};
static const BYTE UNHOOK_PICKER[8] = 								{0x1b,0x04,0x96,0,0,0,0,0xb5};
static const BYTE HOOK_PICKER[8] = 									{0x1b,0x04,0x97,0,0,0,0,0xb6};
static const BYTE MOVE_PRINTER_TO_RECORDER[8] = 		{0x1b,0x04,0x98,0,0,0,0,0xb7};
static const BYTE CHECK_DISCS_LEFT[8] = 						{0x1b,0x04,0x99,0,0,0,0,0xb8};
static const BYTE QUICK_PICK[8] = 									{0x1b,0x04,0x9a,0,0,0,0,0xb9};
static const BYTE DO_HOVER[8] = 										{0x1b,0x04,0x9b,0,0,0,0,0xba};

//Version 2.5.7 Added for BravoPRO
static const BYTE MOVE_LEFTBIN_TO_BOTTOMRECORDER[8] = 			{0x1b,0x04,0x9d,0,0,0,0,0xbc};
static const BYTE MOVE_RIGHTBIN_TO_BOTTOMRECORDER[8] = 			{0x1b,0x04,0x9e,0,0,0,0,0xbd};
static const BYTE MOVE_BOTTOMRECORDER_TO_PRINTER[8] = 			{0x1b,0x04,0x9f,0,0,0,0,0xbe};
static const BYTE MOVE_BOTTOMRECORDER_TO_RIGHTBIN[8] = 			{0x1b,0x04,0xa0,0,0,0,0,0xbf};
static const BYTE MOVE_BOTTOMRECORDER_TO_LEFTBIN[8] = 			{0x1b,0x04,0xa1,0,0,0,0,0xc0};
static const BYTE MOVE_BOTTOMRECORDER_TO_REJECT[8] = 			{0x1b,0x04,0xa2,0,0,0,0,0xc1};
static const BYTE MOVE_TO_BOTTOMRECORDER[8] = 					{0x1b,0x04,0xa3,0,0,0,0,0xc2};
*/

/*
typedef struct tagSystemStatus
{
	TCHAR	tszSystemDesc[50];		// System Description
	TCHAR	tszRoboFWVersion[50];
	INT		nRobot;
	INT		nSystemError;
	TCHAR	tszSystemStatus[MAX_STRING];
	INT		nNumRecDrives;			// Number of recording drives on system
	INT     nDiscsInRightBin;
	INT		nDiscsInLeftBin;
	char    cSystemStatus;
	char	cPtrTrayStatus;
	char    cPickerDiscStatus;
	HANDLE	hRobot;
	INT		nJobsRunning;
	UInt32	dwCurrColorSpits;
	UInt32	dwCurrBlackSpits;
	UInt32	dwFullColorSpits;
	UInt32	dwFullBlackSpits;
} SystemStatus, *pSystemStatus;
*/

typedef struct tagJPSystemInfo
{
	PTRobotInfo RobotInfo;
	PTRobotInfo2 RobotInfo2;
	PTManufactureInfo RobotManfInfo;

} JPSystemInfo;


typedef struct tagJPSystemStatus
{
	PTRobotStatus RobotStatus;
	PTRobotStatus2 RobotStatus2;
	char	tszSystemStatus[MAX_STRING];
	int		nSystemError;

} JPSystemStatus;



typedef struct tagDiscError
{
	int			nDiscIndex;
	UInt32		dwDiscError;
	UInt32		dwSense;
	UInt32		dwCommand;
	UInt32		dwASC;
	UInt32		dwASCQ;
	UInt32		dwSector;
} DiscError, *pDiscError;



typedef struct tagDiscThreadSummary
{
	UInt32		dwDriveID;
	UInt32		dwState;
	UInt32		dwDiscNum;

} DiscThreadSummary, *pDiscThreadSummary;


typedef struct tagJobStatus
{
	UInt32		dwJobID;				// ID of the job, passed to the user in JP_InitJobProcessor
	UInt32		dwJobType;				// Job Type
	UInt32		dwJobState;				// Job State
	int			nPercentComplete;		// Percent Complete (not used)
	int			nNumGoodDiscs;			// Number of good discs produced in job
	int			nNumBadDiscs;			// Number of bad discs produced in job
	int			nNumCopiesTotal;		// Number of discs in the job
	int			nNumCopiesCompleted;	// Number of discs completed in the job
	char		tszStatusString[100];	// status string
	int			nBadDiscsInARow;		// Number of bad disc in a row
	UInt32		dwLastError;			// Last Error
	DiscError	discErrors[10];
	int			nDiscErrors;
	int			nLoadDiscCount;
	int			nLoadDriveIndex[MAX_ROBO_DRIVES];
	int			nLoadDriveState[MAX_ROBO_DRIVES];
	char		cLoadDriveLetter[MAX_ROBO_DRIVES];
	UInt32		dwNumDiscThreads;
	DiscThreadSummary	discThreadSummary[MAX_ROBO_DRIVES+1];
    UInt32      dwColorX100;
    UInt32      dwBlackX100;
    UInt32      dwCyanX100;
    UInt32      dwMagentaX100;
    UInt32      dwYellowX100;
} JobStatus, *pJobStatus;


////////////////////////////////////////////////////////
//                                                    //				
//			      Job Processor Functions             //
//                                                    //
////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_InitializeJobProcessor
//						
//  Description:    This function will initialize the Job Processor and some
//					internal data structures.  It will pass back the DriveInfo
//					structure describing the drives in the system.
//
//	Return:
//			OK if no error
//			ERR_INTERNAL if SDK functions fail
//			ERR_SYSTEM_IN_USE if there already is a job being processed
//
///////////////////////////////////////////////////////////////////
UInt32 JP_InitializeJobProcessor(
						UInt32 * phRobots,
						UInt32 * pdwRobots,
						JPOptions * pJPOptions);

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_TerminateJobProcessor
//		
//  Description:    This function will terminate the Job Processor.
//					
//	Return:
//			OK if no error
//			ERR_INTERNAL if SDK functions fail
//
///////////////////////////////////////////////////////////////////
UInt32 JP_TerminateJobProcessor(void);

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_DisplayRoboticOptions
//
//  Description:    This function will display the Robotic options dialog
//					box.  This dialog allows the user to select persistent
//					robotic options such as kiosk mode, print "Reject",
//					Record and print simultaneously, ...
//							
//	Return:
//			OK if no error
//
///////////////////////////////////////////////////////////////////
UInt32 JP_DisplayRoboticOptions(void);

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_PerformManualMovements
//	
//  Description:    This function will display the manual movement dialog
//					box. This dialog allows the user to perform tests on the
//					robotics of the system.
//						
//	Return:
//			OK if no error
//
///////////////////////////////////////////////////////////////////
UInt32 JP_PerformManualMovements(void);

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetRecordingStatus
//
//  Description:    This function will get return the RecordingStatus structure
//					for the drive identified by DriveID.
//
//	Return:
//			OK if no error
//			ERR_BAD_UNIT if DriveID is invalid.
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetTrackInfo(
								DriveID driveID,	// driveID of the drive being queried
								char * szFile,
								UInt32 * pSeconds); // structure passed to the caller


UInt32 JP_GetRecordingStatus(
				DriveID driveID,	// driveID of the drive being queried
				RecordingStatus * pRecordStat); // structure passed to the caller	
	

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetSystemInfo
//
//  Description:    This function will get return the JPSystemInfo
//					structure for the system.
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetSystemInfo(
								UInt32 hRobot,
								JPSystemInfo * pSysInfo);


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetSystemStatus
//
//  Description:    This function will get return the SystemStatus
//					structure for the system.
//
//	Return:
//			OK if no error
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetSystemStatus(
								UInt32 hRobot,
								JPSystemStatus * pSysStat); // System Status struct


///////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetJobStatus
//
//  Description:    This function will get return the JobStatus structure
//					for the job identified by dwJobID.
//
//	Return:
//			OK if no error
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetJobStatus(
								UInt32 dwJobID,  // JobID to get the status
								JobStatus * pJobStat); // job status structure for jobID



/////////////////////////////////////////////////////////
//
//  JP_CreateMultiSessionJob()
//
/////////////////////////////////////////////////////////
UInt32 JP_CreateMultiSessionJob(
								UInt32 hRobot, 
								char *tszJobName, 
								int nSessions, // Number of copies to write
								UInt32 dwSwapThreshold,
								char * tszSwapPath,
								UInt32 dwJobID,
								pCreateDiscOptions pCreateOpts);  //check for file on disc (cust request 1.14)


UInt32 JP_StartMultiSessionJob(
								UInt32 dwJobID,
								pWriteDiscOptions pWriteOpts);//Version 2.0.0



////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_CreateImageJob
//
//  Description:    This function will set up an Image job.
//					If Merge Text/Photos is to be used, then after this
//					call you should iteratively call JP_AddPrintMergeField().
//					Then, you must call JP_StartImageJob() to actually
//					start the job.
///////////////////////////////////////////////////////////////////
UInt32 JP_CreateImageJob(
								UInt32 hRobot,
								char * tszJobName,
								UInt32 dwJobID,			// jobID passed from the caller.
								int nMediaType,			// Media Type
								UInt32 dwSwapThreshold,
								char * tszSwapPath,
								pCreateDiscOptions pCreateOpts);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_StartImageJob
//
//  Description:    This function will start a Disc Image job on the drives specified
//					in pDriveIDs, using the image file in szFilename and the print file 
//					specified in szPrintFile.  This function will return immediately and
//					upon returning it will have set the jobID to be used in further calls
//					that reference this job.
//
//	Note:   On a Disc Image job this function is the only function necessay to begin the
//		    job.  This is unlike data and audio discs where a call to JP_Create"Data/Audio"Disc
//			is required.
//
//	Return:
//			OK if no error
//			ERR_NO_MANAGED_UNITS if no unit were chosen to be controlled by robotics
//									in the initialization function.
//			ERR_INTERNAL if SDK functions fail
//			ERR_SYSTEM_IN_USE if there already is a job being processed
//			ERR_INVALID_IMAGE_FILE if the image file is invalid.
//			ERR_FEATURE_NOT_IMPLMENTED if fSyncRecordFlag is false, Async recording is not
//										yet implemented
//
//	Ver 3.0.1 - dwJobID is now passed into this function.
//  8/18/2007 - MUST now call JP_CreateImageJob() before making this call!
//
///////////////////////////////////////////////////////////////////
UInt32 JP_StartImageJob(
								UInt32	dwJobID, // JobID passed from caller
								char * tszFilename, // Full path of image file
								UInt32 dwImgType, // GLOBAL_IMAGE or ISO_IMAGE
								UInt32 dwImgMode,  // MODE_1_2048, MODE_2_2336, MODE_2_2352
								pWriteDiscOptions pWriteOpts);  //check for file on disc (cust request 1.14)



////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_CreateDataJob
//
//  Description:    This function will start a Data Disc job on the drives specified
//					in pDriveIDs, using the volume name specified in szVolumeName.
//					This function will return immediately and upon returning it will 
//					have set the jobID to be used in further calls that reference this job.
//
//	Return:
//			OK if no error
//			ERR_INTERNAL if SDK functions fail
//			ERR_SYSTEM_IN_USE if there already is a job being processed
//
//	Ver 3.0.1 - dwJobID is now passed into this function.
///////////////////////////////////////////////////////////////////
UInt32 JP_CreateDataJob(
								UInt32 hRobot, 
								char *tszJobName, 
								char * tszVolumeName, // Volume name for disc
								UInt32 dwJobID,			// jobID passed in from the caller.
								int nMediaType,			// Media Type
								UInt32 dwSwapThreshold,
								char * tszSwapPath,
								pCreateDiscOptions pCreateOpts,
								UInt32 dwJobType);  //check for file on disc (cust request 1.14)

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_CreatePrintOnlyJob
//
//  Description:    This function will set up a Print Only job.
//					If Merge Text/Photos is to be used, then after this
//					call you should iteratively call JP_AddPrintMergeField().
//					Then, you must call JP_StartPrintOnlyJob() to actually
//					start the job.
///////////////////////////////////////////////////////////////////
UInt32 JP_CreatePrintOnlyJob(
								UInt32 hRobot,
								char * tszJobName,
								UInt32 dwJobID);		

////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_StartPrintOnlyJob
//
//  Description:    This function will start a PrintOnly job with the 
//					print file specified in szPrintFile. This function 
//					will return immediately and upon returning it will 
//					have set the jobID to be used in further calls that 
//					reference this job.
//
//	Return:
//			OK if no error
//
//	Ver 3.0.1 - dwJobID is now passed into this function.
///////////////////////////////////////////////////////////////////
UInt32 JP_StartPrintOnlyJob(
								UInt32 dwJobID,
								char * tszPrintFile,
								char * tszMergeFile,
								int nNumCopies,
								int nSourceBin,
								bool fPrintSettingsOverride,
								PTPrinterSettings2 * pPrintSettings,
                                SInt32 dwColorCartWarnPercentage,
                                SInt32 dwBlackCartWarnPercentage,
                                SInt32 dwCyanCartWarnPercentage,
                                SInt32 dwMagentaCartWarnPercentage,
                                SInt32 dwYellowCartWarnPercentage);


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddCompleteDirectoryContents
//
//  Description:    This function will add the complete contents of the directory  
//					specified to the job.  
//
//	Example:		If you add C:\MyTopDir\MySecondDir the contents of MySecondDir
//					will be added to the disc without MySecondDir.
//
//	Return:
//			OK if no error
//			ERR_FILE_LIST_OVERRUN if file list length is exceeded
//
///////////////////////////////////////////////////////////////////
UInt32 JP_AddCompleteDirectoryContents(
								UInt32 dwJobID,
								char * tszSourceDirectory,
								char * tszDestination);


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddFile
//
//
//  Description:    This function will add the file specified to the disc.  
//
//	Return:			OK if no error
//					ERR_FILE_LIST_OVERRUN if file list length is exceeded
//
///////////////////////////////////////////////////////////////////
UInt32 JP_AddFile(
								UInt32 dwJobID, // Job Identifier
								char * tszFileName, // Full path of the file
								char * tszDiscFileName); // Name of the file on the disc


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddPrintMergeField
//
//  Description:    This function will add the specified print
//					merge field to the print job (for SureThing file).
//					NOTE: the SureThing file must be created with Merge field(s)
//
//	NOTES:			tszMergeField must be <= 260 characters
///////////////////////////////////////////////////////////////////
UInt32 JP_AddPrintMergeField(
								UInt32 dwJobID,
								char * tszMergeField );


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddBootable
//
//  Description:    This function will add a bootable file to the disc.  This function
//					is not yet implemented.  
//
//	Return:
//			ERR_FEATURE_NOT_IMPLMENTED
//
///////////////////////////////////////////////////////////////////
UInt32 JP_AddBootable(
								UInt32 dwJobID, // Job Identifier
								char * tszBootImageFile, //Full path of the file
								UInt32 dwRecOpts); // Boot File Options


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_StartDataJob
//
//  Description:    This function will begin a thread to record a data disc for the
//					job described by dwJobID, using the options and speed passed in by
//					the user.  If the szPrintFile is a not NULL then this job will be
//					a burn and print job.  Otherwise it will be burn only.
//
//	Return:
//			OK if no error
//			ERR_NO_MANAGED_UNITS if there are no robotically controlled units.
//			ERR_INVALID_PRINT_FILE if the print file is invalid
//			ERR_FEATURE_NOT_IMPLMENTED Async writes are not yet implemented
//
///////////////////////////////////////////////////////////////////
UInt32 JP_StartDataJob(
								UInt32 dwJobID, // Job Identifier
								bool fPreserveISOVar, // Ver 1.0.8 Preserve ISO Variations.
								pWriteDiscOptions pWriteOpts);	//Version 2.0.0

////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_CreateAudioJob
//
//  Description:    This function will start a Audio Disc job on the drives specified
//					in pDriveIDs. This function will return immediately and upon 
//					returning it will have set the jobID to be used in further calls 
//					that reference this job.
//
//	Return:
//			OK if no error
//			ERR_INTERNAL if SDK functions fail
//			ERR_SYSTEM_IN_USE if there already is a job being processed
//
//	Ver 3.0.1 - dwJobID is now passed into this function.
///////////////////////////////////////////////////////////////////
UInt32 JP_CreateAudioJob(
								UInt32 hRobot, 
								char *tszJobName, 
								UInt32 dwJobID,		// jobID passed in from caller
								pCreateDiscOptions pCreateOpts);  //check for file on disc (cust request 1.14)


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddAudioTrack

//
//  Description:    This function will add the AudioTrack specified to the disc.  
//
//	Return:			OK if no error
//					ERR_FILE_LIST_OVERRUN if file list length is exceeded
//
///////////////////////////////////////////////////////////////////
    UInt32 JP_AddAudioTrack(
                            UInt32 dwJobID,
                            char * tszTrackFile,
                            char * tszDiscFileName,
                            UInt32 dwPreGap);
    
    
////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_AddCDText
//
//
//  Description:    This function will add the CD Text to an audio disc.  
//
///////////////////////////////////////////////////////////////////
UInt32 JP_AddCDText(
								UInt32 dwJobID,
								char * tszTitle,
								char * tszPerformer,
								char * tszComposer);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_StartAudioJob
//
//  Description:    This function will begin a thread to record an audio disc for the
//					job described by dwJobID, using the options and speed passed in by
//					the user.  If the szPrintFile is a not NULL then this job will be
//					a burn and print job.  Otherwise it will be burn only.
//
//	Return:
//			OK if no error
//			ERR_NO_MANAGED_UNITS if there are no robotically controlled units.
//			ERR_INVALID_PRINT_FILE if the print file is invalid
//			ERR_FEATURE_NOT_IMPLMENTED Async writes are not yet implemented
//
///////////////////////////////////////////////////////////////////
UInt32 JP_StartAudioJob(
								UInt32 dwJobID, // Job Identifier
								pWriteDiscOptions pWriteOpts);	//Version 2.0.0



////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_OpenCloseTray
//
//  Description:    This function will open/close the tray of the drive
//					identified by pDrive.  
//
//	Return:
//			OK if no error
//			ERR_DRIVE_TRAY if internal error attempting to open/close tray
//
///////////////////////////////////////////////////////////////////
UInt32 JP_OpenCloseTray(
						UInt32 hRobotID,
						UInt32 dwRow,
						UInt32 dwCol,
						UInt32 dwOpenClose);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_JobActionCommand
//
//  Description:    This function is used to issue an action on a job being
//					processed.  The available options are to abort, pause,
//					or resume a paused job.  
//
//	Return:
//			OK if no error
//
///////////////////////////////////////////////////////////////////
UInt32 JP_JobActionCommand(
								UInt32 dwJobID,
								UInt32 dwDiscID,
								UInt32 dwJobAction);




////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_GetDriveString
//
//  Description:    This function will get the drive string of the 
//                  drive (DriveID).  It will copy only nSize-1 char
//                  of the drive string.  
//
//	Return:
//			JOBERR_NONE if no error
//			JOBERR_INTERNAL_RECORDING if engine ftn fails.
//
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetDriveString(
								DriveID DriveID,      // Drive ID to get String for
								char * tszDriveString, // Array to store drive string
								int nSize);           // Size of szDriveString


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_RequestNewJob
//
//  Description:    This function will return if a job slot is available or not. 
//
//	Return:
//			JOBERR_NONE if a new job can be launched
//			JOBERR_NOT_READY if not ready to accept a new job
//
///////////////////////////////////////////////////////////////////
UInt32 JP_RequestNewJob(UInt32 hRobot);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_RobotSystemAction
//
//  Description:   This function sets a Robot System Action (e.g. align cartridges)
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JP_RobotSystemAction(UInt32 hRobot, UInt32 dwAction);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_GetJPOptions
//
//  Description:   This function gets the JPOptions of the running 
//				   server.  
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetJPOptions(
						JPOptions * pJPOpts);

////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_SetJPOptions
//
//  Description:   This function sets the JPOptions of the running 
//				   server.  Previously you could only set these
//				   settings (kiosk mode, print-first, etc) at startup.
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JP_SetJPOptions(
						JPOptions * pJPOpts);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_SetLanguage
//
//  Description:   This function sets the language for error/status strings.
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JP_SetLanguage(UInt32 dwLanguage);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JP_GetDiscInfo
//
//  Description:   This function gets disc information for the 
//					specified drive.
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JP_GetDiscInfo( 	DriveID driveID,
										DiscInfo * pDiscInfo,
										bool fTurnOFFAIN );


////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetTrackSize
//
//  Description:    This function will get return the track size
//					IF the file is a valid Audio file
//
/////////////////////////////////////////////////////////////////////
UInt32 JP_GetTrackSize( char * tszAudioFile,
											UInt32 * pdwSectors );



////////////////////////////////////////////////////////////////////
//
//	API Function:	JP_GetImageInfo
//
//  Description:    This function will get return the ImageInfo structure
//					for the specified Global Image file
//
/////////////////////////////////////////////////////////////////////
UInt32 JP_GetImageInfo( char* tszImageFile, ImageInfo* pImageInfo );


UInt32 JP_GetRobotOptions(UInt32 hRobot, UInt32 * pdwOptions);

UInt32 JP_SetRobotOptions(UInt32 hRobot, UInt32 dwOptions);

UInt32 JP_USBDisconnectEvent(char * tszRobot, UInt32 dwEventType);

UInt32 JP_USBConnectEvent(UInt32 dwEventType);

UInt32 JP_GetRobotList(UInt32 * phRobots,UInt32 * pdwRobots);

UInt32 JP_GetDriveStatistics( 
								DriveID driveID,
								DriveStatistics * pDriveStats);

UInt32 JP_GeneratePrintPreview(char * tszSource, char * tszDest, UInt32 dwDPI);

UInt32 JP_GetRobotManfInfo(UInt32 hRobot, pPTManufactureInfo pManfInfo);

UInt32 JP_MoveJob(UInt32 dwJobID, char * tszRobot);
	
UInt32 JP_GetDriveInfo(UInt32 hDrive, DriveInfo * myDriveInfo);

#ifdef __cplusplus
}
#endif
